# Accents v0.5.03.2
This repo contains units for the Orthogonal Devices ER-301 Sound Computer.  It currently contains:

* Ring Modulator
* Compare
* Ladder BPF
* Pingable Scaled Random
* Clocked Random Gate
* Weighted Coin Toss
* Motion Sensor
* Ensemble
* Aliasing Pulse
* Flanger
* Carousel Clock Divider
* Maths
* Logics
* Voltage Bank
* Voltage Bank 4
* Voltage Bank 2
* Octave CV Shifter
* Timed Gate
* Scorpio Vocoder
* Linear Sampling VCA
* AB Switch
* XOXOXO (California Stars)
* XOXO (Hey Little Sister)
* XO (Firm Handshake)
* XXXXXX (6 op phase mod synth)
* Rotary Speaker Simulator
* Phaser
* XFade
* Amie (Amplitude modulation synth)

For more details and discussion about these units, please visit:

https://forum.orthogonaldevices.com/t/some-new-units-to-share/1902

