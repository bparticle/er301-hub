local units = {
    {category = "Sequencers"}, 
    {title = "Punch card", moduleName = "Punchcard", keywords = "sequencer, trigger"},
}

return {
    title = "Extras",
    name = "bparticle",
    contact = "via O|D Forums @bparticle",
    keyword = "Extras",
    units = units
}

